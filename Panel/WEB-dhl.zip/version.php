<?php
return array (
  'ver' => '2.2 ',
  'release' => '2016-10-07',
  'vername' => '大灰狼 ',
);
?>
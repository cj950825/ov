<?php

/**
 *
 * @author 李玉江<liyujiang_tk@yeah.net>
 * @copyright Li YuJiang, All Rights Reserved
 * @version 2015/7/25
 * Created by IntelliJ IDEA
 */
final class LinesController extends ApiController
{

    public function main()
    {
        $token = isset($_REQUEST['token']) ? $_REQUEST['token'] : '';
        $tokenController = new TokenController();
        if ($tokenController->check($token)) {
            $cid = addslashes(urldecode($_REQUEST['cid']));
            $model = new ArticleModel();
         //   if ($model->saveValue($data)) {
			 $data = $model->getArticleListByCid($cid);
             $this->responseJson(1, $data); 
          //  } else {
                //$this->responseJson(0, "修改失败");
        //    }
        } else {
            $this->responseJson(0, "请先登录");
        }
    }

}
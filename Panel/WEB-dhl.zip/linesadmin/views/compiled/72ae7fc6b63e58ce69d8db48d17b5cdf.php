﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="Cache-Control" content="no-cache"/>
    <meta name="Pragma" content="no-cache"/>
    <meta name="Expires" content="0"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="Author" content="<?php echo $author; ?>"/>
    <meta name='Keywords' content="<?php echo $seo_keywords; ?>"/>
    <meta name='Description' content="<?php echo $seo_description; ?>"/>
    <meta name="robots" content="all"/>
    <meta name="baidu-site-verification" content="PiOwUHsdmT"/>
    <title><?php echo $title; ?> - <?php echo $seo_title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        body {
            padding: 0;
            margin: 0;
            background: #FFFFFF;
        }

        a:hover {
            text-decoration: none;
        }

        .banner {
            text-align: center;
            background-image: url("<?php echo $base_url; ?>/views/assets/img/banner_bg.png");
            background-size: cover;
            position: relative;
        }

        .banner img {
            display: block;
            margin: 0 auto;
        }

        .download-button a {
            color: #9DD532;
            border: 1px solid #9DD532;
            background: #fff;
            text-decoration: none;
            line-height: 30px;
            border-radius: 10px;
            text-align: center;
            margin: 15px 20px 0;
            display: block;
        }

        .download-button a h4 {
            font-size: 16px;
            display: inline;
        }

        .download-button a span {
            font-size: 12px;
        }

        .download-recommend a {
            color: #fff;
            background: #9DD532;
        }

        .content {
            margin-bottom: 20px;
        }

        .description {
            text-indent: 2em;
        }

        .description,
        .change-log {
            margin: 20px 5px 15px 5px;
        }

        .change-log h2 {
            border-bottom: 1px dashed #ddd;
            color: #41434a;
            font-size: 15px;
            line-height: 36px;
        }

        .change-log ol {
            color: #8c8c8c;
            font-size: 12px;
            line-height: 22px;
            list-style-type: decimal;
            margin-left: 0px;
            margin-top: 10px;
            margin-bottom: 20px;
        }

        @media (min-width: 320px) {
            .banner img {
                width: 320px;
            }

            .change-log h2 {
                font-size: 18px;
            }

            .change-log ol {
                font-size: 14px;
            }
        }

        @media (min-width: 480px) {
            .banner img {
                width: 480px;
            }

            .change-log h2 {
                font-size: 20px;
            }

            .change-log ol {
                font-size: 16px;
            }
        }

        @media (min-width: 720px) {
            .banner img {
                width: 720px;
            }
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript>
<script type="text/javascript">
    /**
     * 新版本检测
     */
    setTimeout(function () {
        try {
            var info = JSON.parse(window.liyujiang.getSoftwareInfo());
            if (info.versionCode < 9) {
                alert("发现新版本，你当前的版本为v" + info.versionName + "，欢迎升级使用");
            } else {
                alert("你当前的版本为v" + info.versionName + "，已经是最新版本，无需升级");
            }
        } catch (e) {
            //出错了，说明不是用我的安卓APP里自带的浏览器组件打开
        }
    }, 1000);
</script>
<div class="content">
    <div class="banner">
        <img alt="." src="<?php echo $base_url; ?>/views/assets/img/banner.jpg"/>
    </div>
    <div class="description">
        <?php echo $seo_description; ?>
    </div>
    <div class="download-button download-recommend">
        <a href="http://pan.baidu.com/s/1c0dPCA0">
            <h4>最新版下载</h4><span>（V1.0.0）</span>
        </a>
    </div>
    <div class="change-log">
        <h2>主要版本更新日志</h2>
        <ol>
            <li>初始版本。</li>
            <li class="download-button" style="list-style: none;">
                <a href="#">
                    <h4>V1.0，2015.12.24</h4>
                </a>
            </li>
        </ol>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/07/27,22:40 -->

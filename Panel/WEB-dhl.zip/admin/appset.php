﻿<?php
$mod='blank';
include("../api.inc.php");
$title='APP编辑';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>


    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php
$user = daddslashes($_GET['app']);
if(!$user || !$row = $DB->get_row("select * from `lyj_link` where id='$user' limit 1")){ exit("配置不存在!");}
if($_POST['type']=="update"){
echo '<div class="panel panel-default">
<div class="panel-heading"><h3 class="panel-title">修改配置结果</h3></div>
<div class="panel-body">';
$name = daddslashes($_POST['name']);
$url = daddslashes($_POST['url']);
	if($DB->query("update `lyj_link` set `name`='$name',`url`='$url' where id='$user'")){
		echo '修改成功！';
	}else{
		echo '修改失败！'.$DB->error();
	}
echo '<hr/><a href="./app.php">>>返回列表</a></div></div>';
exit;
}
?>

              <header class="panel-heading font-bold">编辑APP设置</header>
              <div class="panel-body">
          <form action="./appset.php?app=<?=$user?>" method="post" class="form-horizontal" role="form">
		            <input type="hidden" name="type" value="update" />
              <div class="form-group"><label>&nbsp;&nbsp;类别：</label> <input type="text" value="<?=$row['name']?>" class="form-control" name="name" required="" aria-required="true"></div>
              <div class="form-group"><label>&nbsp;&nbsp;值：</label> <input type="text" value="<?=$row['url']?>" class="form-control" name="url" required="" aria-required="true"></div>
            <br/>
            <input type="submit" value="修改" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>

  <script src="../datepicker/WdatePicker.js"></script><?php 

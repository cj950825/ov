<!doctype html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="../static/index/images/favicon.ico">
<title>管理员后台</title>
<link rel="stylesheet" type="text/css" href="css/default.css">
<link rel="stylesheet" type="text/css" href="css/styles.css">

</head>
<?php
/**
 * 管理中心
**/
$mod='blank';
include("../api.inc.php");
$title='管理中心';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
$count=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$countdaili=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
$mysqlversion=$DB->count("select VERSION()");
		$version = '../version.php';
		$ver = include($version);	
 
 //读取图片换头像
 srand( microtime() * 1000000 );
 $num = rand( 1, 4 );
   
 switch( $num )
 {
 case 1: $image_file = "./sjimg/1.jpg";
     break;
 case 2: $image_file = "./sjimg/2.jpg";
     break;
 case 3: $image_file = "./sjimg/3.jpg";
     break;
 case 4: $image_file = "./sjimg/4.jpg";
     break;
 }

?>
    <section id="content">
        <section class="vbox">
            <section class="scrollable padder">
                <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                    <li>
                        <a href="#">
                            <i class="fa fa-home">
                            </i>
                            <?php echo $title ?>
                        </a>
                    </li>
                </ul>
                <section class="panel panel-default">
                    <div class="row m-l-none m-r-none bg-light lter">
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x text-info">
                                </i>
                                <i class="fa fa-male fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="../admin/qqlist.php">
                                <span class="h3 block m-t-xs">
                                    <strong>
                                        <?php echo $count?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    注册用户
                                </small>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light lt">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x text-warning">
                                </i>
                                <i class="fa fa-bug fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="./qqlist.php">
                                <span class="h3 block m-t-xs">
                                    <strong id="bugs">
                                        <?php echo $count2?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    状态正常
                                </small>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light lt">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x icon-muted">
                                </i>
                                <i class="fa fa-clock-o fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="#">
                                <span class="h3 block m-t-xs">
                                    <strong>
                                        <?php echo date( "H:i") ?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    目前时间
                                </small>
                            </a>
                        </div>
                    </div>
                </section>
				

				
		<div class="col-md-6">
         <section class="panel panel-default">
        <header class="panel-heading font-bold">
        官方公告：</header>
        <div class="panel-body">
        <div class="form-group">
		<b><?php 
                         $url = "https://git.oschina.net/52fancy/OpenVPN/raw/master/notice"; 
                         $contents = file_get_contents($url); 
                         //如果出现中文乱码使用下面代码 
                         //$getcontent = iconv("gb2312", "utf-8",$contents); 
                         echo $contents; 
                         ?></b>
		</div>
        </section>
        </div>

				<div class="col-md-6">
                    <section class="panel panel-default">
                  <div class="panel-body">
                    <div class="clearfix text-center m-t">
                      <div class="inline">
                        <div class="easypiechart" data-percent="100" data-line-width="5" data-bar-color="#32CD32" data-track-Color="#f5f5f5" data-scale-Color="false" data-size="130" data-line-cap='butt' data-animate="1000">
                          <div class="thumb-lg"> 

                          <img src="<?=$image_file?>"  class="img-circle"> </div>
                        </div>
                        <div class="h4 m-t m-b-xs"><?php echo $row[ 'user'] ?></div>
                        <small class="text-muted m-b"><?php echo date("Y-m-d H:i:s") ?></small> </div>
                    </div>
                  </div>
                </section>

                </div>
                <div class="row">
				
				
				
				
                    <div class="col-md-6">
                        <section class="panel panel-default">
           <header class="panel-heading font-bold">
                                服务器状态</header>
                            <div class="panel-body">
         <div class="form-group">
		<li class="list-group-item">
			<b>PHP 版本：</b><?php echo phpversion() ?>
		</li>
		<li class="list-group-item">
			<b>MySQL 版本：</b><?php echo $mysqlversion ?>
		</li>
		<li class="list-group-item">
			<b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
		</li>
		
		<li class="list-group-item">
			<b>程序最大运行时间：</b><?php echo ini_get('max_execution_time') ?>s
		</li>
		<li class="list-group-item">
			<b>POST许可：</b><?php echo ini_get('post_max_size'); ?>
		</li>
		<li class="list-group-item">
			<b>文件上传许可：</b><?php echo ini_get('upload_max_filesize'); ?>
		</div>
        </section>
        </div>
		
		
		

		
         <div class="col-md-6">
                        <section class="panel b-light">
                            <header class="panel-heading bg-primary dker no-border">
                                <strong>
                                    面板信息
                                </strong>
                            </header>
                      <div id="" class="panel-heading bg-primary dker no-border">
              <ul class="list-group">
		
			<p><b>系统版本：</b><?php echo $ver['vername'].' v'.$ver['ver']; ?>
			  </li>
			</p>
			<p>
			  <b>最近更新时间：</b><?php echo $ver['release']; ?>
			  </li>
			  </p>
			
			  <p><b>服务到期时间：</b>2035-07-07
			    </li>
			    </p>
		</li>
	          </ul>              		
	</div>
	
        </div>
        </section>
        
    </aside>
    <!-- end -->
<?php require_once ( "foot.php"); ?><?php 
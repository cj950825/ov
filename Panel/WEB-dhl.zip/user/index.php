<?php

$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
}
if($_POST['km']){
	$km = daddslashes($_POST['km']);
	$myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1");
	if(!$myrow){
		exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
	}else{
		$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		if($res['endtime'] < time()){//已到期
			$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$u.'使用激活码'.$km.'开通账号');
				exit("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
			}
		}else{
			$duetime1 = time() + $myrow['value']*24*60*60;
			$sql="update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`='{$duetime1}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号');
				exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
			}
		}
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$u}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}elseif($_POST['newpass']){
	$newpass = daddslashes($_POST['newpass']);
	if($DB->query("update `openvpn` set `pass` ='$newpass' where `iuser`='$u' && `pass`='$p' limit 1")){
		exit("<script language='javascript'>alert('密码修改成功！');window.location.href='/user/login.php';</script>");
	}else{
		exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
	}
}

$title='用户中心';


$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="../assets/images/favicon_1.ico">

        <title>用户中心</title>

       	<link href="../assets/css/owl.carousel.min.css" rel="stylesheet" type="text/css" />
		<link href="../assets/css/owl.theme.default.min.css" rel="stylesheet" type="text/css" />
		<link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/icons.css"rel="stylesheet"type="text/css"/>
        <link href="../assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/responsive.css" rel="stylesheet" type="text/css" />



        <script src="../assets/js/modernizr.min.js"></script>

    </head>


    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <div class="text-center">
                        <a  class="logo"><i class="icon-magnet icon-c-logo"></i><span>用户中心<i class="md md-album"></i></span></a>
                    </div>
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">



                            <ul class="nav navbar-nav navbar-right pull-right">
                    

                               
                                <li class="dropdown">
                                    <a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"><img src="../assets/images/1.jpg" alt="user-img" class="img-circle"> </a>
                                 <ul class="dropdown-menu">
                                        
                                      <!--  <li><a href="/pay.php"><i class="ti-settings m-r-5"></i>流量充值</a></li> 
                                        <li><a href="/user/newpad.php"><i class="ti-lock m-r-5"></i>修改密码</a></li> -->
                                        <li><a href="/"><i class="ti-power-off m-r-5"></i>退出登录</a></li>
                                    </ul> 
                                </li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->

                <!-- Start content -->
                <div class="content">
                    <div class="container">
                    </br ></br ></br ></br >
                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="page-title">用户中心</h4>
								
                                <p class="text-muted page-title-alt"> <?php echo "<p>欢迎回来：".$res['iuser'];?></p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-3">
                                <div class="widget-bg-color-icon card-box fadeInDown animated">
                                    <div class="bg-icon bg-icon-info pull-left">
                                        <i class="md md-attach-money text-info"></i>
                                    </div>
                                    <div class="text-right">
                                        <h3 class="text-dark"><b class="counter"><?php echo round($res['maxll']/1024/1024);?></b>M</h3>
                                        <p class="text-muted">总共流量</p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <div class="widget-bg-color-icon card-box">
                                    <div class="bg-icon bg-icon-pink pull-left">
                                        <i class="md md-add-shopping-cart text-pink"></i>
                                    </div>
                                    <div class="text-right">
                                        <h3 class="text-dark"><b class="counter"><?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?></b>M</h3>
                                        <p class="text-muted">剩余流量</p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <div class="widget-bg-color-icon card-box">
                                    <div class="bg-icon bg-icon-purple pull-left">
                                        <i class="md md-equalizer text-purple"></i>
                                    </div>
                                    <div class="text-right">
                                        <h3 class="text-dark"><b class="counter"><?php echo round($res['isent']/1024/1024);?></b>M</h3>
                                        <p class="text-muted">上传流量</p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <div class="widget-bg-color-icon card-box">
                                    <div class="bg-icon bg-icon-success pull-left">
                                        <i class="md md-remove-red-eye text-success"></i>
                                    </div>
                                    <div class="text-right">
                                        <h3 class="text-dark"><b class="counter"><?php echo round($res['irecv']/1024/1024);?></b>M</h3>
                                        <p class="text-muted">下载流量</p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
          <div class="row">

<div class="col-lg-4">
<div class="panel panel-default">
<div class="panel-heading">
<div class="clearfix">
<a href class="pull-left thumb-md avatar b-3x m-r">
<img class="img-circle"src="https://cdn.v2ex.com/gravatar/1bebba9bde90e069238f77683fbeaed7?s=42&d=mm&r=g"alt="...">
</a>
<div class="clear">
<div class="h3 m-t-xs m-b-xs"><?php echo $res['iuser'];?>
                    <!--<a href="javascript:email();" onclick="$('.btn-email').attr('disabled',true).text('正在发送-请耐心等待。。。');$('.btn-emeil').text(data)" id="emaildiv" class="btn btn-warning btn-email" type="button" >发送我的流量使用情况到邮箱</a>
                    <i class="fa fa-circle text-success pull-right text-xs m-t-sm"></i>-->
</div>
<!--<small class="text-muted">E-mail: <a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="a8d9d9e8d9d986cbc7c5">[email&#160;protected]</a><script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script></small>-->
</div>
</div>
</div>
<div class="list-group no-radius alt">
<a class="list-group-item">
<i></i> 
                注册日期：<?php echo date('Y-m-d',$res['starttime']);?>            </a>
<a class="list-group-item">
<i></i> 
                到期时期：<?php echo date('Y-m-d',$res['endtime']);?>              </a>
<a class="list-group-item">
<i></i> 
                会员状态：<?=($res['i']?'开通':'禁用')?>				 </a>
</div>
</div>

</div>

<div class="col-lg-5">
<div class="panel panel-default">
<div class="panel-heading">
<div class="clearfix">
<div class="clear">
<div class="h4 m-t-xs m-b-xs">修改密码
                    
</div>
</div>
</div>
</div>
	<form  action="" method="post">
		   <div class="form-group">
		      <div class="col-sm-5">
		         <input type="password" class="form-control" name="newpass" placeholder="请输入新密码">
		      </div>
		   </div>
		   <div class="form-group">
		      <div class="col-sm-offset-1 col-sm-10">
		         <button type="submit" class="btn btn-default">修改</button>
		      </div>
		   </div>
	</form>  
</div>

</div>

<div class="col-md-12">
<div class="card-box">
<h4 class="header-title m-t-0"><b>卡密充值</b></h4>
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<table class="table">
<tbody>
<tr>
<td>用户ID：</td>
<td><?php echo $res['iuser'];?></td>
</tr>
<tr>
<td>剩余流量：</td>
<td><?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?>M</td>
</tr>
</tbody>
</table>
<div class="alert alert-success"><strong>公告：<span><br><?php echo $gonggao;?></span></strong></div>
<ul class="nav nav-tabs tabs">
<li class="active tab">
<a href="#pay-alipay"data-toggle="tab"aria-expanded="false">
<span class="visible-xs"><i></i></span>
<span class="hidden-xs">卡密充值</span>
</a>
</li>
</ul>
<div class="tab-content">
<div class="tab-pane active"id="pay-alipay">
<form action="" method="POST" class="form-inline">
  <div class="form-group">
    <label>激活/续费账号</label>
    <input type="text" class="form-control" name="km" placeholder="请输入激活码卡密">
  </div>
  <button type="submit" class="btn btn-primary">确认</button>
</form>
																						<script>
function cz(){
	$.post('./php/kmapi.php', { user:$('#input_user').val(),card:$('#input_card').val() }, function (text, status) { alert(text); });
}
</script>
</div>
</div>
</div>
</div>
</div>
</div>

<script>
function email(){
	$.get('./php/email.php', 
	function (text, status)  { $("#emaildiv").html(text) });
}
</script>
                        <!-- end row -->


               
                        <!-- end row -->


                    </div> <!-- container -->


            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


            <!-- Right Sidebar -->
            <!-- /Right-bar -->

        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/detect.js"></script>
        <script src="../assets/js/fastclick.js"></script>
        <script src="../assets/js/jquery.slimscroll.js"></script>
        <script src="../assets/js/jquery.blockUI.js"></script>
        <script src="../assets/js/waves.js"></script>
        <script src="../assets/js/wow.min.js"></script>
        <script src="../assets/js/jquery.nicescroll.js"></script>
        <script src="../assets/js/jquery.scrollTo.min.js"></script>


        <script src="../assets/js/jquery.core.js"></script>
        <script src="../assets/js/jquery.app.js"></script>
        
        <script src="../assets/js/owl.carousel.min.js"></script>
        
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                //owl carousel
                $("#owl-slider").owlCarousel({
                    loop:true,
				    nav:false,
				    autoplay:true,
				    autoplayTimeout:4000,
				    autoplayHoverPause:true,
					animateOut: 'fadeOut',
				    responsive:{
				        0:{
				            items:1
				        },
				        600:{
				            items:1
				        },
				        1000:{
				            items:1
				        }
				    }
                });
                
                $("#owl-slider-2").owlCarousel({
                    loop:false,
				    nav:false,
				    autoplay:true,
				    autoplayTimeout:4000,
				    autoplayHoverPause:true,
				    responsive:{
				        0:{
				            items:1
				        },
				        600:{
				            items:1
				        },
				        1000:{
				            items:1
				        }
				    }
                });
                
                //Owl-Multi
                $('#owl-multi').owlCarousel({
				    loop:true,
				    margin:20,
				    nav:false,
				    autoplay:true,
				    responsive:{
				        0:{
				            items:1
				        },
				        480:{
				            items:2
				        },
				        700:{
				            items:4
				        },
				        1000:{
				            items:3
				        },
				        1100:{
				            items:5
				        }
				    }
				})
            });
            
        </script>




    </body>
</html>